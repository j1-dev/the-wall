"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// index.ts
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);

// node_modules/uuid/dist-node/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}

// node_modules/uuid/dist-node/rng.js
var rnds8 = new Uint8Array(16);
function rng() {
  return crypto.getRandomValues(rnds8);
}

// node_modules/uuid/dist-node/v4.js
function v4(options, buf, offset) {
  if (!buf && !options && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return _v4(options, buf, offset);
}
function _v4(options, buf, offset) {
  options = options || {};
  const rnds = options.random ?? options.rng?.() ?? rng();
  if (rnds.length < 16) {
    throw new Error("Random bytes length must be >= 16");
  }
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    if (offset < 0 || offset + 16 > buf.length) {
      throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
    }
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
var v4_default = v4;

// index.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var import_client_apigatewaymanagementapi = require("@aws-sdk/client-apigatewaymanagementapi");
var ddb = new import_client_dynamodb.DynamoDBClient({
  region: "us-east-1",
  ...process.env.DYNAMODB_ENDPOINT && {
    endpoint: process.env.DYNAMODB_ENDPOINT
  }
});
var apigw = new import_client_apigatewaymanagementapi.ApiGatewayManagementApiClient({
  endpoint: process.env.WEBSOCKET
});
var handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));
  const routeKey = event.requestContext.routeKey;
  switch (routeKey) {
    case "$connect":
      return handleConnect(event);
    case "$disconnect":
      return handleDisconnect(event);
    case "$default":
      return handleDefault(event);
    default:
      return {
        statusCode: 400,
        body: "Invalid route key"
      };
  }
};
var handleConnect = async (event) => {
  const connectionId = event.requestContext.connectionId;
  const doc = import_lib_dynamodb.DynamoDBDocumentClient.from(ddb);
  const pk = `CONNECTION#${connectionId}`;
  const sk = `CONNECTION#${connectionId}`;
  const type = "CONNECTION";
  const item = {
    PK: pk,
    SK: sk,
    type,
    connectionId,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  try {
    await doc.send(
      new import_lib_dynamodb.PutCommand({
        TableName: process.env.TABLE_NAME,
        Item: item
      })
    );
    console.log(`Connection ${connectionId} added to DynamoDB`);
    const messages = await doc.send(
      new import_client_dynamodb.QueryCommand({
        TableName: process.env.TABLE_NAME,
        Limit: 50,
        KeyConditionExpression: "#t = :t",
        ExpressionAttributeNames: { "#t": "PK" },
        ExpressionAttributeValues: { ":t": "MESSAGE" },
        ScanIndexForward: false
      })
    );
    if (messages.Items?.length !== 0) {
      try {
        apigw.send(
          new import_client_apigatewaymanagementapi.PostToConnectionCommand({
            ConnectionId: connectionId,
            Data: Buffer.from(JSON.stringify(messages.Items || []))
          })
        );
      } catch (error) {
        console.error("Error sending initial messages |", error);
      }
    }
    return {
      statusCode: 200,
      body: "Connected"
    };
  } catch (error) {
    console.error("Error adding connection to DynamoDB:", error);
    return {
      statusCode: 500,
      body: "Failed to connect"
    };
  }
};
var handleDisconnect = async (event) => {
  const connectionId = event.requestContext.connectionId;
  const doc = import_lib_dynamodb.DynamoDBDocumentClient.from(ddb);
  const pk = `CONNECTION#${connectionId}`;
  const sk = `CONNECTION#${connectionId}`;
  try {
    await doc.send(
      new import_lib_dynamodb.DeleteCommand({
        TableName: process.env.TABLE_NAME,
        Key: { PK: pk, SK: sk }
      })
    );
    console.log(`Connection ${connectionId} removed from DynamoDB`);
    return {
      statusCode: 200,
      body: "Disconnected"
    };
  } catch (error) {
    console.error("Error removing connection from DynamoDB:", error);
    return {
      statusCode: 500,
      body: "Failed to disconnect"
    };
  }
};
var handleDefault = async (event) => {
  const { text, author } = JSON.parse(event.body ?? "{}");
  const connectionId = event.requestContext.connectionId;
  const createdAt = (/* @__PURE__ */ new Date()).toISOString();
  const pk = "MESSAGE";
  const sk = `${createdAt}#${v4_default()}`;
  const validText = text && text.trim() !== "" && text.length <= 500;
  const validAuthor = author && author.trim() !== "" && author.length <= 100;
  if (!validText || !validAuthor) {
    return {
      statusCode: 400,
      body: "Invalid message text"
    };
  }
  const doc = import_lib_dynamodb.DynamoDBDocumentClient.from(ddb);
  const item = {
    PK: pk,
    SK: sk,
    type: "MESSAGE",
    text,
    author,
    createdAt
  };
  try {
    await doc.send(
      new import_lib_dynamodb.PutCommand({
        TableName: process.env.TABLE_NAME,
        Item: item
      })
    );
    console.log(`Message from ${connectionId} added to DynamoDB`);
    return {
      statusCode: 200,
      body: "Message received"
    };
  } catch (error) {
    console.error("Error adding message to DynamoDB:", error);
    return {
      statusCode: 500,
      body: "Failed to process message"
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
